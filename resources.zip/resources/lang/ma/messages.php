<?php
return [
    'home'       => 'ഹോം',
    'about'      => 'ഞങ്ങളെക്കുറിച്ച്',
    'services'   => 'ആനുകൂല്യങ്ങൾ',
];


?>