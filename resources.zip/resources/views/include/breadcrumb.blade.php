<div>
    <ul class="wt-breadcrumb breadcrumb-style-2">
        <li><a href="javascript:void(0);">Home</a></li>
        <li>{{$title}}</li>
    </ul>
</div>