<div class="section-head clearfix">
<div class="wt-tilte-main bdr-r-3 bdr-primary bdr-solid">
<small class="wt-small-title">{{ __('messages.work_service') }}</small>
<h2 class="m-b5">{{ __('messages.why_choose') }}</h2>
</div>
<div class="title-right-detail">
<p>{{ __('messages.service_small_content') }}</p>
</div>
</div> 